export class TodoDto {
    name: string;
   description: string;
 }